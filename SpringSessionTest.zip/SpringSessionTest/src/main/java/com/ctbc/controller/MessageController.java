package com.ctbc.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
public class MessageController {
	
	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;
	
	@MessageMapping("/test2")
	public void test(String str, Principal principal) {
		simpMessagingTemplate.convertAndSendToUser(principal.getName(), "/queue/msg", "haha2");
	}

}
