package com.ctbc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	public HomeController() {
		System.out.println("------ HomeController ------");
	}

	@RequestMapping(value = "/")
	public String init() {
		System.out.println("this is init");
		return "index";
	}
	
}
