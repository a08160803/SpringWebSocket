package config;

import java.security.Principal;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptorAdapter;
import org.springframework.session.ExpiringSession;
import org.springframework.session.SessionRepository;
import org.springframework.session.web.socket.config.annotation.AbstractSessionWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.server.support.DefaultHandshakeHandler;

import com.ctbc.model.vo.User;

@Configuration
@EnableWebSocketMessageBroker
public class WebsocketSTOMPConfig extends AbstractSessionWebSocketMessageBrokerConfigurer<ExpiringSession> {

	public WebsocketSTOMPConfig() {
		System.out.println("--------- this is websocket stomp config ----------");
	}
	
//	@Autowired
//	private SessionRepository sessionRepository;
	
	/**
	 * AbstractSessionWebSocketMessageBrokerConfigurer实现了在handshake时获取httpsession，并且每次websocket消息发生时也刷新了httpsession的时间。同时在websocket
	 * session中加入了SPRING.SESSION.ID字段。
	 */

	@Override
	protected void configureStompEndpoints(StompEndpointRegistry registry) {
		registry.addEndpoint("/ws")
				.addInterceptors(new SessionAuthHandshakeInterceptor())
				.setHandshakeHandler(new DefaultHandshakeHandler() {
					@Override
					protected Principal determineUser(ServerHttpRequest request, WebSocketHandler wsHandler,
							Map<String, Object> attributes) {
						return new MyPrincipal((User) attributes.get("user"));
					}
				}).setAllowedOrigins("http://127.0.0.1:8081");
	}

	// 配置客戶端入站通道
	@SuppressWarnings("deprecation")
	@Override
	public void configureClientInboundChannel(ChannelRegistration registration) {
		registration.setInterceptors(new ChannelInterceptorAdapter() {
			@Override
			public Message<?> preSend(Message<?> message, MessageChannel channel) {
				System.out.println("recv : " + message);
				StompHeaderAccessor accessor = StompHeaderAccessor.wrap(message);
				// ---------------------------------------------------------------
				// 獲得User的兩種方式:
				// 1. 在configureClientInboundChannel中可以通过以下获得User
				// 2. 在WebsocketSTOMPConfig中注入SessionRepository来获得springsession
				User user = (User) accessor.getSessionAttributes().get("user");
//				sessionRepository.getSession((String)accessor.getSessionAttributes().get("SPRING.SESSION.ID"));
				// ---------------------------------------------------------------
				return super.preSend(message, channel);
			}
		});
	}

	// 配置客戶端出站通道
	@SuppressWarnings("deprecation")
	@Override
	public void configureClientOutboundChannel(ChannelRegistration registration) {
		registration.setInterceptors(new ChannelInterceptorAdapter() {
			@Override
			public Message<?> preSend(Message<?> message, MessageChannel channel) {
				System.out.println("send : " + message);
				return super.preSend(message, channel);
			}
		});
		super.configureClientOutboundChannel(registration);
	}

	@Override
	public void configureMessageBroker(MessageBrokerRegistry registry) {
		// 这是配置到 @MessageMapping Controller
		registry.setApplicationDestinationPrefixes("/app");
		// 直接到broker message handler
		registry.enableSimpleBroker("/topic", "/queue");
	}

	class MyPrincipal implements Principal {

		private User user;

		public MyPrincipal(User user) {
			this.user = user;
		}

		@Override
		public String getName() {
			return String.valueOf(user.getId());
		}

	}

}
